import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.Timer;

public class Wall {
    double x;
    double y;
    double width;
    double height;
    int R;
    int G;
    int B;
    Rectangle2D rectangle = new Rectangle2D.Double();

    public Wall(double x, double y, double width, double height, int r, int g, int b) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.R=r;
        this.G=g;
        this.B=b;
        rectangle.setRect(x, y, width, height);
    }

    public void paint(Graphics g) {
        g.setColor(new Color(G, G, B));
        g.fillRect((int)x, (int)y, (int) width, (int) height);
    }

}
